StudentDAO.java
import java.sql.*;

public class StudentDAO {

    public void addStudent(String name, int age, String course) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO student(name, age, course) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, course);
            ps.executeUpdate();
            System.out.println("Student added successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewStudents() {
        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM student");

            while (rs.next()) {
                System.out.println(
                    rs.getInt("id") + " | " +
                    rs.getString("name") + " | " +
                    rs.getInt("age") + " | " +
                    rs.getString("course")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


🖥️ 4. MainApp.java
import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        StudentDAO dao = new StudentDAO();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Name: ");
                    sc.nextLine();
                    String name = sc.nextLine();

                    System.out.print("Age: ");
                    int age = sc.nextInt();

                    System.out.print("Course: ");
                    sc.nextLine();
                    String course = sc.nextLine();

                    dao.addStudent(name, age, course);
                    break;

                case 2:
                    dao.viewStudents();
                    break;

                case 3:
                    System.out.println("Thank You!");
                    System.exit(0);
            }
        }
    }
}